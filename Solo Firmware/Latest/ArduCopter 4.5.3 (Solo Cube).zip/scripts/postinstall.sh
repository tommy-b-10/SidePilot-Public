#!/bin/sh
set -e

# Set executable permission on each file in this package
# chmod a+x /usr/bin/pixhawk.py
# chmod a+x /usr/bin/uploader.py
# chmod a+x /usr/bin/GoProManager.py
# chmod a+x /usr/bin/modes.py
# chmod a+x /usr/bin/shotManager.py
